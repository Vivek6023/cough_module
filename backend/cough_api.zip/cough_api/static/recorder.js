let recorder;
let chunks = [];

function startRecording() {
    navigator.mediaDevices.getUserMedia({ audio: true })
        .then(stream => {
            recorder = new MediaRecorder(stream);
            recorder.start();
            chunks = [];

            recorder.ondataavailable = e => chunks.push(e.data);
        });
}

function stopRecording() {
    recorder.stop();

    recorder.onstop = () => {
        const blob = new Blob(chunks, { type: "audio/wav" });
        const formData = new FormData();
        formData.append("audio", blob, "cough.wav");

        fetch("/api/predict-cough/", {
            method: "POST",
            body: formData
        })
        .then(res => res.json())
        .then(data => {
    document.getElementById("result").innerHTML = `
        <div>
            <p><strong>Prediction:</strong> ${data.prediction}</p>
            <p><strong>Confidence:</strong> ${(data.confidence * 100).toFixed(1)}%</p>
        </div>
    `;
});


    };
}
